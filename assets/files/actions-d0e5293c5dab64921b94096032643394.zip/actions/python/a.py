import matplotlib.pyplot as plt

x = range(1,10)
y = range(1,10)
plt.plot(x,y)
plt.show()