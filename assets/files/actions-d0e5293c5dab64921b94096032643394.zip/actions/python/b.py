import pandas
df = pandas.read_json("./x.json")
df.head()